package com.bacteria.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Random;

class myVector2d{
    public float x;
    public float y;
    myVector2d(float _x , float _y){
        x = _x;
        y = _y;
    }
    public myVector2d norm(){
        Double d = Math.sqrt(x*x+y*y);
        if(d != 0){
            x /= d;
            y /= d;
        }
        return this;
    }
    public double dist(){
        return Math.sqrt(x*x+y*y);
    }
}

class myButton{
    public Bitmap just;
    public Bitmap active;
    public int timePress , x , y;
    public int maxTimePress = 500;
    public boolean pressed = false;
    public boolean click = false;
    public boolean show = true;
    public String text = "";
    public void draw(Canvas canvas , Paint p){
        canvas.drawBitmap(just, x, y, p);
        if (255*timePress/maxTimePress > 0) {
            p.setAlpha(255*timePress/maxTimePress);
            canvas.drawBitmap(active, x, y, p);
        }
        p.setAlpha(255);
    }
    int width(){
        return just.getWidth();
    }
    int height(){
        return just.getHeight();
    }
    void init() {
        Canvas canvas = new Canvas(just);
        Paint p = new Paint();
        p.setFlags(Paint.ANTI_ALIAS_FLAG);
        p.setTextAlign(Paint.Align.CENTER);
        //p.setTextSize(WHmin/25);
        canvas.drawText(text , width()/2 , height()/2 , p);
    }
}

enum GameMod { ACTIVE_GAME, SURVIVAL, PAUSE, MAP_MENU, LEVEL_MENU , GLOBAL_MENU , SETTING , BETWEEN_LEVEL}

public class FullscreenActivity extends Activity implements OnTouchListener {

    public Bitmap scaleToWidth(Bitmap b , int width){
        return Bitmap.createScaledBitmap(b , width, width*b.getHeight()/b.getWidth() , false);
    }
    public Bitmap bitmapLoadRaw(int raw){
        InputStream imageIS;
        imageIS = getResources().openRawResource(raw);
        return  BitmapFactory.decodeStream(imageIS);
    }
    public float distBetween(float x1, float y1, float x2, float y2){
        return (float) Math.sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
    }

    GameMod gameMod = GameMod.MAP_MENU;

    AdView adView;

    BackgroundSound backgroundSound = new BackgroundSound();

    Drawable dr;

    Bitmap fonImgB , buttonNextLevel , buttonWhile;
    Bitmap[] iconLevel = new Bitmap[4];
    Bitmap[] virusImg = new Bitmap[9];
    Bitmap[][] GameMap = new Bitmap[3][2];
    Bitmap[][][] bactImg = new Bitmap[9][2][3];
    Bitmap borderImg;
    int[] bactRadius = new int[3];
    int[][] bactColor = {{100,255,150}  ,  {255,100,100}  ,  {100,150,255} ,
            {255,140,200} , {255,255,0} , {255,255,255} , {0,0,0} , {0,0,0} , {0,0,0}};
    public int gameHardLevel = 100;
    public int gameLevel = 0;
    public int mapLevel = 0;
    public int score = 0;
    public int countAtacBact = 100;
    public int timeToAtacBact = 60000;
    int timeSurvival = 0;
    public int playerIndexBact = 0;
    public int xxxReplaceIt = 8;
    public int WHmin;
    public float overWidth; // use for different DPI;
    public float mouseX, mouseY;
    public boolean canDrawLine;
    public boolean needInit = false;
    DisplayMetrics metrics = new DisplayMetrics();
    Random rn = new Random();

    EditText etText;
    SharedPreferences sPref;

    long startTimeLevel, finishTimeLevel;

    DrawView dv;

    ArrayList<Integer> passageTime = new ArrayList<Integer>();
    ArrayList<Bacteria> bact = new ArrayList<Bacteria>();
    ArrayList<Virus> virus = new ArrayList<Virus>();
    ArrayList<GameLevel> gameLevels = new ArrayList<GameLevel>();
    ArrayList<myButton> myButtons = new ArrayList<myButton>();

    class LoadStruct{
        public float x,y;
        public int paintTypeRadius , team;
    }

    class GameLevel{
        ArrayList<LoadStruct> one = new ArrayList<LoadStruct>();
        int[] times = new int[2];
    }

    class Virus{
        public float x,y,dx,dy,vx,vy;
        public int team,target,parent;
        public void move(float TL){
            myVector2d vec = new myVector2d(dx,dy);

            Bacteria b = bact.get(target);
            if(vec.dist() > 1){
                vec.norm();
            }
            myVector2d vec2 = new myVector2d(b.x - x, b.y - y).norm();
            vec.x += vec2.x*0.7;
            vec.y += vec2.y*0.7;

            vec.norm();

            vx += vec.x;
            vy += vec.y;



            x += (vx+(rn.nextInt(100)-50)/50.0)*overWidth*1.5*TL;
            y += (vy+(rn.nextInt(100)-50)/50.0)*overWidth*1.5*TL;

            //x+= vec.x;
            //y+= vec.y;
            vx *= 0.85;
            vy *= 0.85;

            dx = dy = 0;
        }
    }

    class floatingNumber{
        public int number,team;
        public float life,x,y;
    }

    ArrayList<floatingNumber> floatingNumbers= new ArrayList<floatingNumber>();

    class Bacteria{
        public float x;
        public float y;
        public float dx;
        public float dy;
        public int radius;
        public int paintTypeRadius;
        public int team;
        public boolean select;
        public boolean tmpSelect;
        public float count;
        public float maxCount;
        public float drawBorder = 0;
        public float lastNotif = 0;

        public void move(float TL){
            drawBorder -= 1;
            lastNotif += 16.7*TL;
            x += dx*overWidth*TL;
            y += dy*overWidth*TL;
            dx *= 0.95;
            dy *= 0.95;
            if(team != xxxReplaceIt) {
                count += TL * 0.1 * Math.cos(Math.min(3.1415, 3.1415 / 2 * count / maxCount));
            }
        }

        public void fire(int target , int parent){
            float tmpCount = bact.get(parent).count/2;
            for(int i=0; i<tmpCount; i++){
                Virus tmp = new Virus();
                tmp.dx = tmp.dy = 0;
                tmp.x = x + rn.nextInt(30) -15;
                tmp.y = y + rn.nextInt(30) -15;
                tmp.team = team;
                tmp.target = target;
                tmp.parent = parent;
                virus.add(tmp);
                count -= 1;
            }
            myVector2d vec = new myVector2d(bact.get(target).x - bact.get(parent).x ,bact.get(target).y - bact.get(parent).y ).norm();
            dx -= vec.x*count*0.05 + vec.x;
            dy -= vec.y*count*0.05 + vec.y;
        }
    }

    public void DrawMapMenu(Canvas canvas, Paint p){
        canvas.drawBitmap(fonImgB, 0, 0, p);
        for(int i=0; i < 3; i++) {
            myButton b = myButtons.get(i);
            b.draw(canvas,p);
            if(b.click){
                gameMod = GameMod.LEVEL_MENU;
                mapLevel = i;
                b.click = false;
                needInit = true;
            }
        }
    }

    public void DrawBetweenLevel(Canvas canvas, Paint p){
        canvas.drawBitmap(fonImgB, 0, 0, p);

        for (int i = 0; i < bact.size(); i++) {
            Bacteria b = bact.get(i);
            int s = 0;
            if (b.select || b.tmpSelect) {
                s = 1;
            }
            Bitmap tmpBitmap = bactImg[b.team][s][b.paintTypeRadius];
            if (b.drawBorder > 0) {
                p.setColor(Color.argb((int) b.drawBorder * 3, bactColor[b.team][0], bactColor[b.team][1], bactColor[b.team][2]));
                canvas.drawCircle(b.x, b.y, bactImg[b.team][1][b.paintTypeRadius].getWidth() / 2 + (float) (5 + b.drawBorder * 0.3), p);
                p.setColor(Color.BLACK);
            }

            canvas.drawBitmap(tmpBitmap, b.x - tmpBitmap.getWidth() / 2, b.y - tmpBitmap.getWidth() / 2, p);
        }

        for(int i = 0; i < virus.size(); i++){
            Virus l = virus.get(i);
            canvas.drawBitmap(virusImg[l.team] , l.x - 6 , l.y - 6 , p);

        }


        canvas.drawBitmap(borderImg,0,0,p);

        canvas.drawText("Your result " + Long.toString((finishTimeLevel - startTimeLevel)/1000) + ","
                + Long.toString((finishTimeLevel - startTimeLevel) % 1000) + "s" , (int)(0.5*metrics.widthPixels) , (float) (0.16*metrics.heightPixels), p);

        canvas.drawText("Green level - " + Integer.toString(gameLevels.get(gameLevel).times[0]) + " Blue level - " + Integer.toString(gameLevels.get(gameLevel).times[1]) , (int)(0.5*metrics.widthPixels) , (float) (0.20*metrics.heightPixels), p);


        for (myButton b : myButtons) {
            b.show = true;
            b.draw(canvas, p);
            if (b.click) {
                Log.e("" , "Yes, button click");
                b.click = false;
                gameMod = GameMod.ACTIVE_GAME;
                needInit = true;
                gameLevel++;
            }
        }
    }

    public void DrawPause(Canvas canvas, Paint p){
        canvas.drawBitmap(fonImgB, 0, 0, p);

        for (int i = 0; i < bact.size(); i++) {
            Bacteria b = bact.get(i);
            int s = 0;
            if (b.select || b.tmpSelect) {
                s = 1;
            }
            Bitmap tmpBitmap = bactImg[b.team][s][b.paintTypeRadius];
            if (b.drawBorder > 0) {
                p.setColor(Color.argb((int) b.drawBorder * 3, bactColor[b.team][0], bactColor[b.team][1], bactColor[b.team][2]));
                canvas.drawCircle(b.x, b.y, bactImg[b.team][1][b.paintTypeRadius].getWidth() / 2 + (float) (5 + b.drawBorder * 0.3), p);
                p.setColor(Color.BLACK);
            }

            canvas.drawBitmap(tmpBitmap, b.x - tmpBitmap.getWidth() / 2, b.y - tmpBitmap.getWidth() / 2, p);
        }

        for(int i = 0; i < virus.size(); i++){
            Virus l = virus.get(i);
            canvas.drawBitmap(virusImg[l.team] , l.x - 6 , l.y - 6 , p);

        }


        canvas.drawBitmap(borderImg,0,0,p);

        /*for (myButton b : myButtons) {
            b.show = true;
            b.draw(canvas, p);
            if (b.click) {
                b.click = false;


                gameMod = GameMod.ACTIVE_GAME;
                needInit = true;
                gameLevel++;
            }
        }*/

        for(int i = 0; i < myButtons.size(); i++) {
            myButton b = myButtons.get(i);
            b.show = true;
            b.draw(canvas,p);
            if(b.click){

                switch (i){
                    case 0:
                        gameMod = GameMod.ACTIVE_GAME;
                        break;
                    case 1:
                        gameMod = GameMod.MAP_MENU;
                        needInit = true;
                        break;
                    case 2:
                        gameMod = GameMod.ACTIVE_GAME;
                        needInit = true;
                        break;
                }
                b.click = false;
            }
        }
    }

    public void DrawActiveGame(Canvas canvas, Paint p , float timeLag, int width , int height){
        canvas.drawBitmap(fonImgB, 0, 0, p);

        boolean playerWin = true;
        boolean playerLose = true;
        for(Bacteria b : bact){
            if(b.team != playerIndexBact){
                playerWin = false;
            }else{
                playerLose = false;
            }
        }

        for(Virus l : virus){
            if(l.team != playerIndexBact){
                playerWin = false;
            }else{
                playerLose = false;
            }
        }



        for (int i = 0; i < bact.size(); i++) {
            Bacteria b = bact.get(i);
            int s = 0;
            if (b.select || b.tmpSelect) {
                s = 1;
            }
            Bitmap tmpBitmap = bactImg[b.team][s][b.paintTypeRadius];
            if (b.drawBorder > 0) {
                p.setColor(Color.argb((int)b.drawBorder * 3, bactColor[b.team][0], bactColor[b.team][1], bactColor[b.team][2]));
                canvas.drawCircle(b.x, b.y, bactImg[b.team][1][b.paintTypeRadius].getWidth() / 2 + (float) (5 + b.drawBorder * 0.3), p);
                p.setColor(Color.BLACK);
            }

            canvas.drawBitmap(tmpBitmap, b.x - tmpBitmap.getWidth() / 2, b.y - tmpBitmap.getWidth() / 2, p);
            //canvas.drawText(Integer.toString((int) b.count), b.x, b.y + WHmin/75 , p);

            float dist;
            float minDist = 9999999;
            int curKey = -1;


            for (int j = 0; j < bact.size(); j++) {
                if(i == j) continue;
                Bacteria bj = bact.get(j);
                dist = distBetween(b.x, b.y, bj.x, bj.y) - (b.radius + bj.radius);
                if (dist < minDist) {
                    minDist = dist;
                    curKey = j;
                }

                if (b.team != playerIndexBact && bj.team != b.team && b.team != xxxReplaceIt) {
                    if (rn.nextInt(1000) < gameHardLevel &&
                            dist / overWidth < rn.nextInt(1000) * rn.nextInt(1000) / 1000 &&
                            b.count / b.maxCount * 10000 > 1000 + rn.nextInt(100) * rn.nextInt(100)  &&
                            b.count - bj.count  > 10 - (rn.nextInt(20) * rn.nextInt(20) / 20)
                            ) {
                        b.fire(j, i);
                    }
                }
            }


            if (minDist < 0) {
                myVector2d vec = new myVector2d(bact.get(curKey).x - b.x, bact.get(curKey).y - b.y).norm();

                b.dx -= vec.x;
                b.dy -= vec.y;

                bact.get(curKey).dx += vec.x;
                bact.get(curKey).dy += vec.y;
            }


            if (b.x + b.radius > width)  b.dx -= 0.5;
            if (b.y + b.radius > height) b.dy -= 0.5;
            if (b.x - b.radius < 0)      b.dx += 0.5;
            if (b.y - b.radius < 0)      b.dy += 0.5;

            b.move(timeLag);

            for (int j = virus.size() - 1; j >= 0; j--) {
                Virus l = virus.get(j);
                dist = distBetween(l.x, l.y, b.x ,b.y);
                if (dist < b.radius) {
                    if (i == l.target && dist < b.radius) {

                        if (b.team == l.team) {
                            b.count++;
                        } else {
                            b.count--;
                            if(b.lastNotif > 32){
                                b.lastNotif = 0;
                                floatingNumber tmp = new floatingNumber();
                                tmp.x = (int)b.x+(rn.nextInt(300)-150)*overWidth;
                                tmp.y = (int)b.y+(rn.nextInt(300)-150)*overWidth*0;
                                tmp.team = l.team;
                                tmp.life = 1500;
                                tmp.number = (int)b.count+1;
                                floatingNumbers.add(tmp);
                            }
                            if(b.count < 1) { // capture
                                b.count = 0;
                                b.team = l.team;
                                b.select = b.tmpSelect = false;
                                b.drawBorder = 60;
                            }
                        }

                        myVector2d vec = new myVector2d(b.x - l.x, b.y - l.y).norm();

                        b.dx += vec.x * 0.01 * (b.radius-dist);  // important
                        b.dy += vec.y * 0.01 * (b.radius-dist);

                        virus.remove(j);

                    } else if (!(l.parent == i || l.target == i)) {
                        myVector2d vec = new myVector2d(b.x - l.x, b.y - l.y).norm();
                        float g = (b.radius + 20 - dist) / 30;
                        l.dx += -vec.x * g;
                        l.dy += -vec.y * g;
                    }
                }
            }
        }

        for(int i = floatingNumbers.size()-1; i >= 0; i--){
            floatingNumber n = floatingNumbers.get(i);
            p.setColor(Color.rgb(bactColor[n.team][0] , bactColor[n.team][1] , bactColor[n.team][2]));
            p.setAlpha((int) (255*n.life/1500));
            canvas.drawText(Integer.toString(n.number) , n.x , n.y , p);
            n.life -= 16*timeLag;
            n.y -= WHmin/360.0*timeLag;
            if(n.life < 0) floatingNumbers.remove(i);
        }
        p.setAlpha(255);

        p.setStrokeWidth((float) (bactRadius[0] * 0.1));
        p.setColor(Color.WHITE);
        if (canDrawLine) {
            for (Bacteria b : bact) {
                if (b.select) canvas.drawLine(mouseX, mouseY, b.x, b.y, p);
            }
        }
        p.setColor(Color.BLACK);

        for(int i = 0; i < virus.size(); i++){
            Virus l = virus.get(i);
            l.move(timeLag);
            canvas.drawBitmap(virusImg[l.team] , l.x - 6 , l.y - 6 , p);

        }

        timeToAtacBact -= 16*timeLag;
        timeSurvival += 16*timeLag;
        canvas.drawText(Integer.toString(timeToAtacBact/1000) , 200 , 200 , p);
        if(timeToAtacBact < 0){
            timeToAtacBact = 30000;
            countAtacBact+= 10;
            for(int i=0; i< countAtacBact; i++){
                Virus tmp = new Virus();
                tmp.dx = tmp.dy = 0;
                tmp.x = rn.nextInt(300) -150;
                tmp.y = rn.nextInt(300) -150 ;
                tmp.team = 2;
                tmp.target = 1 + rn.nextInt(bact.size()-1);
                tmp.parent = 0;
                virus.add(tmp);
            }
        }

        /*if(rn.nextInt(10000) < 30){
            int team = 1+rn.nextInt(5);
            for(int i=0; i< countAtacBact; i++){
                Virus tmp = new Virus();
                tmp.dx = tmp.dy = 0;
                tmp.x = rn.nextInt(300) -150;
                tmp.y = rn.nextInt(300) -150 ;
                tmp.team = team;
                tmp.target = 1 + rn.nextInt(bact.size()-1);
                tmp.parent = 0;
                virus.add(tmp);
            }
        }*/

        if(playerLose || playerWin) {
            finishTimeLevel = System.currentTimeMillis();
            if((gameMod == GameMod.SURVIVAL || true) && playerWin && false){
                countAtacBact+= 10;
                for(int i=0; i< countAtacBact; i++){
                    Virus tmp = new Virus();
                    tmp.dx = tmp.dy = 0;
                    tmp.x = rn.nextInt(300) -150;
                    tmp.y = rn.nextInt(300) -150 ;
                    tmp.team = 2;
                    tmp.target = 1 + rn.nextInt(bact.size()-1);
                    tmp.parent = 0;
                    virus.add(tmp);
                }
                bact.get(0).team = 2;
            }else {
                /*for (myButton b : myButtons) {
                    b.show = true;
                    b.draw(canvas, p);
                    if (b.click) {
                        Log.e("" , "Yes, button click");
                        b.click = false;
                        gameMod = GameMod.BETWEEN_LEVEL;
                        needInit = true;
                        if (playerWin) {
                            //gameLevel++;
                        }
                    }
                }*/
                gameMod = GameMod.BETWEEN_LEVEL;
                if(passageTime.size() <= gameLevel){
                    passageTime.add((int) ((finishTimeLevel - startTimeLevel)/1000));
                }else{
                    int time = passageTime.get(gameLevel);
                    if( time > (int) ((finishTimeLevel - startTimeLevel)/1000)){
                        passageTime.set(gameLevel , (int) ((finishTimeLevel - startTimeLevel)/1000));
                    }
                }

                sPref = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor ed = sPref.edit();

                String str = "";
                for(int i = 0; i < passageTime.size(); i++){
                    str += Integer.toString(passageTime.get(i))+" ";
                }

                ed.putString("passage_time_1", str);
                ed.commit();
                needInit = true;
            }
        }
    }

    public void myInit(){
        Log.e("WOOO WOOO" , "azaza");
        switch (gameMod){
            case LEVEL_MENU:
                swithcAdv(true);
                myButtons.clear();
                for(int i = 0; i < 15; i++){
                    myButton b = new myButton();

                    if(passageTime.size() > i){
                        if(passageTime.get(i) < gameLevels.get(i).times[0]){
                            b.just = iconLevel[0];
                        }else if(passageTime.get(i) < gameLevels.get(i).times[1]){
                            b.just = iconLevel[1];
                        }else{
                            b.just = iconLevel[2];
                        }
                    }else{
                        b.just = iconLevel[3];
                    }



                    b.active = bactImg[(mapLevel+2) % 3][0][1];
                    b.timePress = 0;
                    int width = metrics.widthPixels;
                    float lX = (int) (width * 0.2 * (i % 5)  );
                    float lY = (int) ((width * 0.2 * (i / 5)) );
                    b.x = (int)lX;
                    b.y = (int)lY;

                    myButtons.add(b);
                }
                break;
            case MAP_MENU:
                swithcAdv(true);
                myButtons.clear();
                //int offset = (int) (metrics.widthPixels*0.17);
                for(int i = 0; i < 3; i++){
                    myButton b =  new myButton();
                    b.just = GameMap[i][0];
                    b.active = GameMap[i][1];

                    //b.x = 0;
                    //offset += b.width()+metrics.widthPixels*0.01;
                    //b.y = 100;
                    switch (i){
                        case 0:
                        b.x = 0;
                        b.y = 0;
                        break;
                        case 1:
                        b.x = 0;
                        b.y = GameMap[0][0].getHeight();
                        break;
                        case 2:
                        b.x = metrics.widthPixels - GameMap[1][0].getWidth();
                        b.y = b.y = GameMap[0][0].getHeight();
                        break;
                    }

                    b.timePress = 0;
                    myButtons.add(b);
                }

                break;
            case ACTIVE_GAME:
            case SURVIVAL:
                Log.e("" , Integer.toString(gameLevel));
                swithcAdv(false);
                bact.clear();
                virus.clear();
                for(int i = 0; i < gameLevels.get(gameLevel).one.size(); i++){
                    Bacteria newbact = new Bacteria();
                    newbact.x = gameLevels.get(gameLevel).one.get(i).x;
                    newbact.y = gameLevels.get(gameLevel).one.get(i).y;
                    newbact.team = gameLevels.get(gameLevel).one.get(i).team;
                    newbact.paintTypeRadius = gameLevels.get(gameLevel).one.get(i).paintTypeRadius;
                    newbact.radius = bactRadius[newbact.paintTypeRadius];
                    newbact.maxCount = 32 + newbact.paintTypeRadius*32;
                    bact.add(newbact);
                }
                myButtons.clear();
                myButton b =  new myButton();
                b.just = buttonNextLevel;
                b.active = buttonNextLevel;
                b.click = false;b.show = false;

                b.x = 0;
                b.y = (int) (metrics.heightPixels - b.just.getHeight()*1.3);
                b.timePress = 0;
                myButtons.add(b);
                startTimeLevel = System.currentTimeMillis();
                break;
            case GLOBAL_MENU:

                myButtons.clear();
                for(int i = 0; i < 4; i++){
                    b = new myButton();
                    b.just = buttonWhile;
                    b.active = buttonWhile;
                    b.text = "SomeTextA";
                    b.init();
                    b.x = (i/2)*metrics.widthPixels/2;
                    b.y = (i % 2)*metrics.heightPixels/2;
                    b.timePress = 0;
                    myButtons.add(b);
                }
                break;
            case BETWEEN_LEVEL:
                swithcAdv(true);
                myButtons.clear();
                b =  new myButton();
                b.just = buttonNextLevel;
                b.active = buttonNextLevel;
                b.click = false;b.show = false;

                b.x = (int) (metrics.widthPixels*0.20);
                b.y = (int) (metrics.heightPixels - b.just.getHeight()*2.5);
                b.timePress = 0;
                myButtons.add(b);
                break;
            case PAUSE:
                myButtons.clear();
                for(int i = 0; i < 3; i++){
                    b = new myButton();

                    b.just = buttonNextLevel;
                    b.active = buttonNextLevel;
                    b.click = false;b.show = false;

                    b.x = (int) (metrics.widthPixels*0.20);
                    b.y = (int) (metrics.heightPixels - b.just.getHeight()*2.5 - b.just.getHeight()*1.5*i);
                    b.timePress = 0;
                    myButtons.add(b);
                }
        }
        if(dv != null){
            dv.drawThread.update = 1000;
        }
    }

    public void swithcAdv(boolean show){
        if(adView != null) {
            if (!show) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        adView.pause();
                        adView.setVisibility(View.GONE);
                        adView.setEnabled(false);
                    }
                });
            } else {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        adView.setVisibility(View.VISIBLE);
                        adView.setEnabled(true);
                    }
                });
            }
        }
    }

    public void pause(){

        switch (gameMod){
        case ACTIVE_GAME:
        case SURVIVAL:
            //gameMod = GameMod.LEVEL_MENU;
            gameMod = GameMod.PAUSE;
            break;
        case LEVEL_MENU:
            gameMod = GameMod.MAP_MENU;
            break;
        case MAP_MENU:
            gameMod = GameMod.GLOBAL_MENU;
            break;
        }
        needInit = true;
    }

    @Override
    public void onBackPressed() {
        if(gameMod == GameMod.GLOBAL_MENU){
            AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
            alertDialog.setTitle("Выйти?");

            alertDialog.setMessage("Вы действительно хотите выйти?");

            alertDialog.setPositiveButton("Да", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog,int which) {
                    finish();
                }
            });

            alertDialog.setNegativeButton("Нет", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });

            alertDialog.show();
        }
        pause(); }

    public boolean onTouch(View v, MotionEvent event) {

        float x = event.getX();
        float y = event.getY();
        boolean oneSelect , bactClick;

        mouseX = x;
        mouseY = y;

        if( dv != null) dv.drawThread.update(); // maybe it's not need to do

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                for(myButton b : myButtons){
                    if (!b.show) continue;
                    if (mouseX > b.x && mouseX < b.x + b.width() && mouseY > b.y && mouseY < b.y + b.height()) {
                        if(Color.alpha(b.just.getPixel((int)mouseX - b.x, (int)mouseY - b.y)) > 100 ) b.pressed = true;
                    }
                }

                canDrawLine = true;
                bactClick = false;

                for( int i = 0; i < bact.size(); i++){
                    Bacteria b = bact.get(i);
                    if( (b.x - x)*(b.x - x) + (b.y - y)*(b.y - y) < b.radius*b.radius ){
                        bactClick = true;
                        if(b.select || b.team != playerIndexBact) {
                            for (int j = 0; j < bact.size(); j++) {
                                if (bact.get(j).select && bact.get(j).team == playerIndexBact && i!=j) {
                                    bact.get(j).fire(i, j);
                                    b.tmpSelect = b.select = false;
                                    bact.get(j).select = bact.get(j).tmpSelect = false;
                                }
                            }
                        }else if(b.team == playerIndexBact) { b.select = true;}
                    }
                }

                if(!bactClick){
                    for (Bacteria b : bact) {
                        b.select = false;
                    }
                }
                break;
            case MotionEvent.ACTION_MOVE:
                oneSelect = false;
                for (Bacteria b : bact) {
                    if (b.select) {
                        oneSelect = true;
                        break;
                    }
                }

                for (Bacteria b : bact) {
                    b.tmpSelect = false;
                    if ((b.x - x) * (b.x - x) + (b.y - y) * (b.y - y) < b.radius * b.radius) {
                        if (b.team == playerIndexBact) {
                            b.select = true;
                            b.drawBorder = Math.max(b.drawBorder , 30);
                        } else if (oneSelect){
                            b.tmpSelect = true;
                        }
                    }
                }

                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                for(myButton b : myButtons){
                    if (mouseX > b.x && mouseX < b.x + b.width() && mouseY > b.y && mouseY < b.y + b.height()) {
                        if(b.pressed && b.show) {
                            if (Color.alpha(b.just.getPixel((int) mouseX - b.x, (int) mouseY - b.y)) > 100){
                                b.click = true;
                            }
                        }
                    }
                    b.pressed = false;
                }

                canDrawLine = false;
                for( int i = 0; i < bact.size(); i++){
                    Bacteria b = bact.get(i);
                    if( (b.x - x)*(b.x - x) + (b.y - y)*(b.y - y) < b.radius*b.radius ){
                        if(b.team != playerIndexBact){
                            for( int j = 0; j < bact.size(); j++){
                                if(bact.get(j).select && bact.get(j).team == playerIndexBact){
                                    bact.get(j).fire(i,j);
                                    bact.get(j).select = bact.get(j).tmpSelect = false;
                                    b.tmpSelect = b.select = false;
                                }
                            }
                        }
                    }
                }

                break;
        }
        return true;
    }

    public class BackgroundSound extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... params) {
            MediaPlayer player = MediaPlayer.create(getApplicationContext(), R.raw.music);
            player.setLooping(true);
            player.setVolume(100,100);
            player.start();

            return null;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        backgroundSound.doInBackground();

        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        super.onCreate(savedInstanceState);

        WHmin = Math.min(metrics.widthPixels, metrics.heightPixels);
        overWidth = (float) (WHmin / 1920.0);

        bactRadius[0] = (int) (WHmin / 11.32);
        bactRadius[1] = WHmin / 7;
        bactRadius[2] = WHmin / 5;



        iconLevel[0] = scaleToWidth(bitmapLoadRaw(R.raw.icongreen) , WHmin/4);
        iconLevel[1] = scaleToWidth(bitmapLoadRaw(R.raw.icon) , WHmin/4);
        iconLevel[2] = scaleToWidth(bitmapLoadRaw(R.raw.iconred) , WHmin/4);
        iconLevel[3] = scaleToWidth(bitmapLoadRaw(R.raw.icondis) , WHmin/4);
        fonImgB = Bitmap.createScaledBitmap(bitmapLoadRaw(R.raw.fon), metrics.widthPixels ,metrics.heightPixels,true);
        buttonNextLevel = scaleToWidth(bitmapLoadRaw(R.raw.buttonnext) , (int) (metrics.widthPixels*0.6));
        buttonWhile=  scaleToWidth(bitmapLoadRaw(R.raw.buttonjust) , metrics.widthPixels/2);

        borderImg = scaleToWidth(bitmapLoadRaw(R.raw.between),metrics.widthPixels);
        /*for(int i = 0; i < 3; i++){
            GameMap[i][0] = scaleToWidth(bitmapLoadRaw(R.raw.map2) , (int)(metrics.widthPixels*0.22));
            GameMap[i][1] = scaleToWidth(bitmapLoadRaw(R.raw.map2blur) , (int)(metrics.widthPixels*0.22));
        }*/

        GameMap[1][0] = scaleToWidth(bitmapLoadRaw(R.raw.easy) , (int) (metrics.widthPixels*0.94*0.5));
        GameMap[1][1] = scaleToWidth(bitmapLoadRaw(R.raw.easy) , (int) (metrics.widthPixels*0.94*0.5));

        GameMap[2][0] = scaleToWidth(bitmapLoadRaw(R.raw.hard) , (int) (metrics.widthPixels*0.94*0.5));
        GameMap[2][1] = scaleToWidth(bitmapLoadRaw(R.raw.hard) , (int) (metrics.widthPixels*0.94*0.5));

        GameMap[0][0] = scaleToWidth(bitmapLoadRaw(R.raw.survival) , metrics.widthPixels);
        GameMap[0][1] = scaleToWidth(bitmapLoadRaw(R.raw.survival) , metrics.widthPixels);


        //GameMap[0][1] = scaleToWidth(bitmapLoadRaw(R.raw.map2blur) , (int)(metrics.widthPixels*0.22));

        BufferedReader reader = new BufferedReader(new InputStreamReader(getResources().openRawResource(R.raw.level)));
        String line;

        GameLevel tmp = new GameLevel();
        boolean readTime = true;

        try {
            while ((line = reader.readLine()) != null) {
                if (line.length() < 5) {
                    gameLevels.add(tmp);
                    tmp = new GameLevel();
                    readTime = true;
                } else {
                    String[] number = line.split(" ");
                    if(readTime){
                        tmp.times[0] = Integer.parseInt(number[0]);
                        tmp.times[1] = Integer.parseInt(number[1]);
                        readTime = false;
                    }else {
                        LoadStruct tmpStruct = new LoadStruct();
                        tmpStruct.x = Integer.parseInt(number[0]) * metrics.widthPixels / 1920;
                        tmpStruct.y = Integer.parseInt(number[1]) * metrics.heightPixels / 1080;
                        tmpStruct.team = Integer.parseInt(number[2]);
                        tmpStruct.paintTypeRadius = Integer.parseInt(number[3]);

                        tmp.one.add(tmpStruct);
                    }
                }
            }
        } catch (IOException e) {}

        gameLevels.add(tmp);





        sPref = getPreferences(MODE_PRIVATE);
        String passage_time_1 = sPref.getString("passage_time_1", "");
        if(passage_time_1.length() > 0) {
            String[] number = passage_time_1.split(" ");
            for (int i = 0; i < number.length; i++) {
                passageTime.add(Integer.parseInt(number[i]));
            }
        }






        myInit();

        dv = new DrawView(this);
        dv.setOnTouchListener(this);

        setContentView(R.layout.activity_fullscreen);

        LinearLayout layout = (LinearLayout) this.findViewById(R.id.mainLayout);
        layout.addView(dv);
        adView = (AdView)this.findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().addTestDevice("7EA36A5ED8E30D30307C99C349AFEDEE").build();

        adView.loadAd(adRequest); // ITS LOAD MY CPU
    }

    class DrawView extends SurfaceView implements SurfaceHolder.Callback {
        Paint p;
        private DrawThread drawThread;
        long timeout = System.currentTimeMillis();
        long curTime;


        public DrawView(Context context) {
            super(context);
            getHolder().addCallback(this);
            getHolder().setFormat(PixelFormat.RGBA_8888);

            Typeface fontFace = Typeface.createFromAsset(getAssets(), "fonts/komix.ttf");
            p = new Paint();
            p.setTypeface(fontFace);
            p.setFlags(Paint.ANTI_ALIAS_FLAG);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(WHmin/25);
            p.setFilterBitmap(true);

            Paint pp = new Paint();
            pp.setFlags(Paint.ANTI_ALIAS_FLAG);

            Bitmap bm = bitmapLoadRaw(R.raw.bact);

            for( int j = 0; j < 3; j++){
                Bitmap bmS = Bitmap.createScaledBitmap(bm, bactRadius[j]*2, bactRadius[j]*2, true);
                for( int i = 0 ; i < 9; i++){
                    if(i > 5 && i != 8)
                        continue;

                    int r,g,b;
                    r = bactColor[i][0];
                    g = bactColor[i][1];
                    b = bactColor[i][2];
                    bactImg[i][0][j] = Bitmap.createBitmap(bactRadius[j]*2,bactRadius[j]*2,Bitmap.Config.ARGB_8888);
                    bactImg[i][1][j] = Bitmap.createBitmap((int)(bactRadius[j]*2.4),(int)(bactRadius[j]*2.4),
                            Bitmap.Config.ARGB_8888);

                    pp.setStyle(Paint.Style.FILL);
                    Canvas canvasB = new Canvas(bactImg[i][0][j]);
                    canvasB.drawBitmap(bmS , 0 , 0 , pp);
                    pp.setColor(Color.argb(120 , r,g,b));
                    canvasB.drawCircle(bactRadius[j], bactRadius[j], (float) (bactRadius[j] - bactRadius[0]*0.05), pp);

                    canvasB = new Canvas((bactImg[i][1][j]));
                    canvasB.drawBitmap(bmS , (int)(bactRadius[j]*0.2) , (int)(bactRadius[j]*0.2) , pp);
                    pp.setColor(Color.argb(200 , r,g,b));
                    canvasB.drawCircle((int)(bactRadius[j]*1.2) , (int)(bactRadius[j]*1.2) , bactRadius[j]-1 , pp);
                    pp.setStyle(Paint.Style.STROKE);
                    pp.setStrokeWidth((float)(bactRadius[j]*0.1));
                    pp.setColor(Color.WHITE);

                    canvasB.drawCircle((int)(bactRadius[j]*1.2) , (int)(bactRadius[j]*1.2) ,
                            bactRadius[j]+(float)(bactRadius[j]*0.1) ,pp);
                }
            }

            virusImg[0] = bitmapLoadRaw(R.raw.virus);
            virusImg[1] = bitmapLoadRaw(R.raw.virus2);
            virusImg[2] = bitmapLoadRaw(R.raw.virus3);
            pp.setStyle(Paint.Style.FILL);
            pp.setAlpha(255);

            for(int i = 0; i < 9; i++){
                int r,g,b;
                r = bactColor[i][0];
                g = bactColor[i][1];
                b = bactColor[i][2];

                //Color.

                /*for(int x = 0; x < virusImg[i].getWidth(); x++){
                    for(int y = 0; y < virusImg[i].getHeight(); y++){
                        // получим каждый пиксель
                        int pixelColor = virusImg[i].getPixel(x, y);
                        Color c = Color.

                        // получим информацию о прозрачности
                        int pixelAlpha = Color.alpha(pixelColor);
                        // получим цвет каждого пикселя
                        int pixelRed = Color.red(pixelColor);
                        int pixelGreen = Color.green(pixelColor);
                        int pixelBlue = Color.blue(pixelColor);
                        // перемешаем цвета
                        int newPixel= Color.argb(
                                pixelAlpha, pixelBlue, pixelRed, pixelGreen);
                        // полученный результат вернём в Bitmap
                        virusImg[i].setPixel(x, y, newPixel);
                    }
                }*/

                float radius = (float) (WHmin/120.0);
                virusImg[i] = Bitmap.createBitmap((int)(radius*2) , (int) (radius*2), Bitmap.Config.ARGB_8888);
                Canvas canvasB = new Canvas(virusImg[i]);
                pp.setColor(Color.argb(255 , r,g,b));
                canvasB.drawCircle(radius, radius , radius , pp);
            }

            sPref = getPreferences(MODE_PRIVATE);
            SharedPreferences.Editor ed = sPref.edit();


            ed.putString("passage_time_1", "");
            ed.commit();
        }

        @Override
        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {}

        @Override
        public void surfaceCreated(SurfaceHolder holder) {
            drawThread = new DrawThread(getHolder());
            drawThread.setRunning(true);
            drawThread.start();
        }

        @Override
        public void surfaceDestroyed(SurfaceHolder holder) {
            boolean retry = true;
            drawThread.setRunning(false);
            while (retry) {
                try {
                    drawThread.join();
                    retry = false;
                } catch (InterruptedException e) {
                }
            }
        }

        class DrawThread extends Thread {

            public boolean running = false;
            public float update = 1000;
            private SurfaceHolder surfaceHolder;

            public DrawThread(SurfaceHolder surfaceHolder) {
                this.surfaceHolder = surfaceHolder;
            }

            public void setRunning(boolean running) {
                this.running = running;
            }
            public void update() {this.update = 1000;}

            @Override
            public void run() {
                Canvas canvas;
                while (running) {
                    //Log.e("update" , Integer.toString((int) update));
                    curTime = System.currentTimeMillis() - timeout;
                    timeout = System.currentTimeMillis();
                    if (update > 0) {
                        canvas = null;
                        try {
                            canvas = surfaceHolder.lockCanvas(null);
                            if (canvas == null) continue;


                            float timeLag = curTime/16;
                            timeLag = Math.min(3,(float)Math.max(0.3, timeLag));

                            //Log.e("" , gameMod.toString());


                            switch (gameMod){
                            case MAP_MENU:

                                update -= curTime;
                                DrawMapMenu(canvas,p);
                                break;


                            case LEVEL_MENU:
                                if (update > 0) {
                                    update -= curTime;
                                    canvas.drawBitmap(fonImgB, 0, 0, p);
                                    for (int i = 0; i < myButtons.size(); i++) {
                                        myButton b = myButtons.get(i);
                                        if(b.click){
                                            b.click = false;
                                            if(i < passageTime.size() + 1) {
                                                gameMod = GameMod.ACTIVE_GAME;
                                                gameLevel = i;
                                                needInit = true;
                                            }
                                        }
                                        b.draw(canvas,p);
                                        canvas.drawText(Integer.toString(i+1), b.x+b.width()/2,
                                                b.y+b.height()/2 + WHmin/75, p);
                                    }
                                }
                                break;
                            case BETWEEN_LEVEL:
                                DrawBetweenLevel(canvas, p);
                                //update = 1000;
                                //DrawActiveGame(canvas,p,timeLag,getWidth(),getHeight());
                                break;
                            case PAUSE:
                                DrawPause(canvas, p);
                                break;
                            case ACTIVE_GAME:
                            case SURVIVAL:
                                update = 1000;
                                DrawActiveGame(canvas,p,timeLag,getWidth(),getHeight());
                                break;
                            }

                            for(myButton b : myButtons){
                                int last = b.timePress;
                                if(b.pressed) {
                                    b.timePress = (int) Math.min(b.timePress+curTime , b.maxTimePress);
                                }else{
                                    b.timePress = (int) Math.max(b.timePress-curTime , 0);
                                }
                                if(b.timePress != last) update = 1000;
                            }

                            canvas.drawText(Long.toString(curTime) , 100 , 100 , p);

                            //canvas.drawText(Long.toString((long) (16*timeLag)), 100, 100, p);

                        } finally {
                            if (canvas != null) {
                                surfaceHolder.unlockCanvasAndPost(canvas);
                            }
                        }
                    }else{
                        try {
                            Thread.sleep(16);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    if(needInit){
                        needInit = false;
                        myInit();
                    }
                }
            }
        }
    }
}





